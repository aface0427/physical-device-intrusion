<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInputValue
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btncancel = New System.Windows.Forms.Button
        Me.btnok = New System.Windows.Forms.Button
        Me.btClr = New System.Windows.Forms.Button
        Me.btPlus = New System.Windows.Forms.Button
        Me.btMinus = New System.Windows.Forms.Button
        Me.btndel = New System.Windows.Forms.Button
        Me.btncommon = New System.Windows.Forms.Button
        Me.Button10 = New System.Windows.Forms.Button
        Me.Button9 = New System.Windows.Forms.Button
        Me.Button8 = New System.Windows.Forms.Button
        Me.Button7 = New System.Windows.Forms.Button
        Me.txtValue = New System.Windows.Forms.TextBox
        Me.Button6 = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btncancel
        '
        Me.btncancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btncancel.Location = New System.Drawing.Point(256, 116)
        Me.btncancel.Margin = New System.Windows.Forms.Padding(7)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(97, 46)
        Me.btncancel.TabIndex = 35
        Me.btncancel.Tag = ""
        Me.btncancel.Text = "Cancel"
        Me.btncancel.UseVisualStyleBackColor = True
        '
        'btnok
        '
        Me.btnok.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.btnok.Location = New System.Drawing.Point(256, 56)
        Me.btnok.Margin = New System.Windows.Forms.Padding(7)
        Me.btnok.Name = "btnok"
        Me.btnok.Size = New System.Drawing.Size(97, 46)
        Me.btnok.TabIndex = 34
        Me.btnok.Tag = ""
        Me.btnok.Text = "OK"
        Me.btnok.UseVisualStyleBackColor = True
        '
        'btClr
        '
        Me.btClr.Location = New System.Drawing.Point(195, 174)
        Me.btClr.Margin = New System.Windows.Forms.Padding(7)
        Me.btClr.Name = "btClr"
        Me.btClr.Size = New System.Drawing.Size(47, 46)
        Me.btClr.TabIndex = 33
        Me.btClr.Tag = ""
        Me.btClr.Text = "C"
        Me.btClr.UseVisualStyleBackColor = True
        '
        'btPlus
        '
        Me.btPlus.Location = New System.Drawing.Point(195, 114)
        Me.btPlus.Margin = New System.Windows.Forms.Padding(7)
        Me.btPlus.Name = "btPlus"
        Me.btPlus.Size = New System.Drawing.Size(47, 46)
        Me.btPlus.TabIndex = 32
        Me.btPlus.Tag = ""
        Me.btPlus.Text = "+"
        Me.btPlus.UseVisualStyleBackColor = True
        '
        'btMinus
        '
        Me.btMinus.Location = New System.Drawing.Point(195, 56)
        Me.btMinus.Margin = New System.Windows.Forms.Padding(7)
        Me.btMinus.Name = "btMinus"
        Me.btMinus.Size = New System.Drawing.Size(47, 46)
        Me.btMinus.TabIndex = 31
        Me.btMinus.Tag = ""
        Me.btMinus.Text = "-"
        Me.btMinus.UseVisualStyleBackColor = True
        '
        'btndel
        '
        Me.btndel.Location = New System.Drawing.Point(134, 234)
        Me.btndel.Margin = New System.Windows.Forms.Padding(7)
        Me.btndel.Name = "btndel"
        Me.btndel.Size = New System.Drawing.Size(47, 46)
        Me.btndel.TabIndex = 30
        Me.btndel.Tag = ""
        Me.btndel.Text = "<"
        Me.btndel.UseVisualStyleBackColor = True
        '
        'btncommon
        '
        Me.btncommon.Location = New System.Drawing.Point(73, 234)
        Me.btncommon.Margin = New System.Windows.Forms.Padding(7)
        Me.btncommon.Name = "btncommon"
        Me.btncommon.Size = New System.Drawing.Size(47, 46)
        Me.btncommon.TabIndex = 29
        Me.btncommon.Tag = ""
        Me.btncommon.Text = "."
        Me.btncommon.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(134, 56)
        Me.Button10.Margin = New System.Windows.Forms.Padding(7)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(47, 46)
        Me.Button10.TabIndex = 28
        Me.Button10.Tag = "9"
        Me.Button10.Text = "9"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(73, 56)
        Me.Button9.Margin = New System.Windows.Forms.Padding(7)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(47, 46)
        Me.Button9.TabIndex = 27
        Me.Button9.Tag = "8"
        Me.Button9.Text = "8"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(12, 56)
        Me.Button8.Margin = New System.Windows.Forms.Padding(7)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(47, 46)
        Me.Button8.TabIndex = 26
        Me.Button8.Tag = "7"
        Me.Button8.Text = "7"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(134, 114)
        Me.Button7.Margin = New System.Windows.Forms.Padding(7)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(47, 46)
        Me.Button7.TabIndex = 25
        Me.Button7.Tag = "6"
        Me.Button7.Text = "6"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'txtValue
        '
        Me.txtValue.Location = New System.Drawing.Point(12, 12)
        Me.txtValue.Name = "txtValue"
        Me.txtValue.Size = New System.Drawing.Size(341, 34)
        Me.txtValue.TabIndex = 24
        Me.txtValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(73, 114)
        Me.Button6.Margin = New System.Windows.Forms.Padding(7)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(47, 46)
        Me.Button6.TabIndex = 23
        Me.Button6.Tag = "5"
        Me.Button6.Text = "5"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(12, 114)
        Me.Button5.Margin = New System.Windows.Forms.Padding(7)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(47, 46)
        Me.Button5.TabIndex = 22
        Me.Button5.Tag = "4"
        Me.Button5.Text = "4"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(134, 174)
        Me.Button4.Margin = New System.Windows.Forms.Padding(7)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(47, 46)
        Me.Button4.TabIndex = 21
        Me.Button4.Tag = "3"
        Me.Button4.Text = "3"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(73, 174)
        Me.Button3.Margin = New System.Windows.Forms.Padding(7)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(47, 46)
        Me.Button3.TabIndex = 20
        Me.Button3.Tag = "2"
        Me.Button3.Text = "2"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(12, 174)
        Me.Button2.Margin = New System.Windows.Forms.Padding(7)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(47, 46)
        Me.Button2.TabIndex = 19
        Me.Button2.Tag = "1"
        Me.Button2.Text = "1"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 234)
        Me.Button1.Margin = New System.Windows.Forms.Padding(7)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(47, 46)
        Me.Button1.TabIndex = 18
        Me.Button1.Tag = "0"
        Me.Button1.Text = "0"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'frmInputValue
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 27.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(360, 300)
        Me.Controls.Add(Me.btncancel)
        Me.Controls.Add(Me.btnok)
        Me.Controls.Add(Me.btClr)
        Me.Controls.Add(Me.btPlus)
        Me.Controls.Add(Me.btMinus)
        Me.Controls.Add(Me.btndel)
        Me.Controls.Add(Me.btncommon)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.txtValue)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Font = New System.Drawing.Font("Arial Black", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(7, 7, 7, 7)
        Me.Name = "frmInputValue"
        Me.Text = "Input Value"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents btnok As System.Windows.Forms.Button
    Friend WithEvents btClr As System.Windows.Forms.Button
    Friend WithEvents btPlus As System.Windows.Forms.Button
    Friend WithEvents btMinus As System.Windows.Forms.Button
    Friend WithEvents btndel As System.Windows.Forms.Button
    Friend WithEvents btncommon As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents txtValue As System.Windows.Forms.TextBox
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
